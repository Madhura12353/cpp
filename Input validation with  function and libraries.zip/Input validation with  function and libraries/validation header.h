
void printBanner();
//This function used for input validation when user give letters insted of numbers
int getInteger();
double getNumber();
int getMultipleOf(int input);
char getLetter();
double getNumInRange(int min, int max);
int getPerfectSquare();

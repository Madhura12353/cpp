#pragma once
//const int SIZE = 70;
double getNumber();
int getInteger();
int getPositiveInteger();
int getIntInrange(int min, int max);
int getBaseInRange(int min, int max);


